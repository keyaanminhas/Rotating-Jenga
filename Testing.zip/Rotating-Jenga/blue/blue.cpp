#include "blue.h"





void Ble32::setup(const String name){
	_name = name;
	_SerialBT.begin(_name);
}

void Ble32::setup(const int rx, const int tx){
    _name = name;
    _SerialBT = new SoftwareSerial(rx, tx);

    }
}


Ble32::~Ble32(){
    #ifndef ESP32
    delete _SerialBT;
    #endif
}

String Ble32::read(){
    #ifdef ESP32
	if (_SerialBT.available()){
		return String(_SerialBT.read());
	}
    #else
    if (_SerialBT->available()){
        return String(_SerialBT->read());
    }
    #endif
	return String("[NOTHING]");


    }


